﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebPayments
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
   
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            ContentPlaceHolder mpContentPlaceHolder;
            TextBox mpTextBox;
            mpContentPlaceHolder = (ContentPlaceHolder)Master.FindControl("MainContent");
            if (mpContentPlaceHolder != null)
            {
                mpTextBox = (TextBox)mpContentPlaceHolder.FindControl("CustomerVaultId");
                if (mpTextBox != null)
                {
                   string text = mpTextBox.Text;
                    Response.Redirect("YouSubmitted.aspx?text=" + text);
                }
                else
                { Response.Redirect("YouSubmitted.aspx?text=NOTHING"); }
            }
            else
            { Response.Redirect("YouSubmitted.aspx?text=Text Box Not Found"); }
        }
    }
}